package edu.handong.csee.java.lab03.gift;

public class Gift {

    
}