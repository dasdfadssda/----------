package edu.handong.csee.java.lab03.user;

public class User {

  private String name;
  private String email;
  private int age;

  public String getName(){
    return name;
  }

  public void setName(String newName){
    name = newName;
  }

  public String getEmail(){
    return email;
  }

  public void setEmail(String newEmail){
    email = newEmail;
  }

  public int getAge(){
    return age;
  }

  public void setAge(int userAge){
    age = userAge;
  }


}

