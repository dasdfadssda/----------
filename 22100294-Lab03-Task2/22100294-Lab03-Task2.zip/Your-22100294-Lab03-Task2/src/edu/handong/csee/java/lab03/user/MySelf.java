package edu.handong.csee.java.lab03.user;

public class MySelf extends User {

    private boolean openProfile;

    public boolean getOpenProfile() {
        return openProfile;
    }

    public void setOpenProfile(boolean oProfile)  {
        openProfile = oProfile;
    }

}